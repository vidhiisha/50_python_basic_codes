def is_palindrome_string(s):
    return s==s[::-1]

print(is_palindrome_string(input()))