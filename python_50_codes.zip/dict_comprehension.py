squares={x:x*x for x in range(1,6)}
print(squares)