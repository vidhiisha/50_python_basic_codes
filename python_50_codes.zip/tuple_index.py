t=(1,2,3)
print(t.index(2))