a={'x':1,'y':2}
b={'z':3}
a.update(b)
print(a)