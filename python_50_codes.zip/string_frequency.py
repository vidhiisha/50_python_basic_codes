from collections import Counter

s=input()
print(dict(Counter(s)))