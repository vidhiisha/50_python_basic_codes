def list_max(lst):
    return max(lst)

lst=list(map(int,input().split()))
print(list_max(lst))