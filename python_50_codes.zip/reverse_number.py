def reverse_number(n):
    return int(str(n)[::-1])

print(reverse_number(int(input("Enter a number: "))))