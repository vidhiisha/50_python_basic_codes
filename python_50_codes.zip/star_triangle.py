def star_triangle(n):
    for i in range(1,n+1):
        print('*'*i)

star_triangle(5)