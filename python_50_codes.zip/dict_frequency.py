from collections import Counter

lst=list(map(int,input().split()))
print(dict(Counter(lst)))