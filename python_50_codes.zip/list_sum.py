def list_sum(lst):
    return sum(lst)

lst=list(map(int,input().split()))
print(list_sum(lst))